import { LightningElement, track, wire } from 'lwc';
import retrieveAccountRecords from '@salesforce/apex/AccountsData.retrieveAccountRecords';
export default class DisplayAccountsData extends LightningElement {
    @wire (retrieveAccountRecords) accData;
    @track getAccId;
}